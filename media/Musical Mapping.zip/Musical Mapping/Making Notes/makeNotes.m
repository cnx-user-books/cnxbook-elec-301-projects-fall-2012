function out = makeNotes(notes, DUR, instrmt, wavefm, tempo, Fs)
%
% This function compose notes.
%
% Input
% notes - a vector of notes
% DUR - a vector of duration in term of beats
% wavefm - the waveform used to synthesize the note
% tempo - tempo;
% instrmt - 'guitar','drum','woodwind', 'horn', 'clarinet', 'oboe', 
% 'bassoon', 'flute', 'piccolo', 'sax', 'trumpet', 'tuba', 'trombone'
% Fs - sampling rate
%
% Output
% out - the structure contain the sound for each note
%
freq = music.note2freq(notes); % convert notes to correspondent frequencies
N = length(freq);
t_beat = 60/tempo; % time per beat
dur = t_beat*DUR; % duration in s

if strcmp(instrmt, 'guitar')==1 % synthesize guitar notes
    for i = 1:N
        NOTE = Karplus_Strong(freq(i), 0.5, dur(i), Fs);
        if size(NOTE,1)==1;
            NOTE = NOTE';
        end
        out(i).notes = NOTE;
    end
elseif strcmp(instrmt, 'drum')==1 % synthesize drum notes
    for i = 1:N
        NOTE = drum(freq(i), dur(i), Fs, 1/2, 2);
        if size(NOTE,1)==1;
            NOTE = NOTE';
        end
        out(i).notes = NOTE;
    end
elseif strcmp(instrmt, 'woodwind')==1 % synthesize woodwind notes
    for i = 1:N
        NOTE = modifiedKS(freq(i), dur(i), Fs, 20);
        if size(NOTE,1)==1;
            NOTE = NOTE';
        end
        out(i).notes = NOTE;
    end
elseif strcmp(instrmt, 'horn')==1 % synthesize horn notes
    for i = 1:N
        [NOTE, t, f, a] = wind_instrument_note('horn',Fs, dur(i), 1, freq(i));
        if size(NOTE,1)==1;
            NOTE = NOTE';
        end
        out(i).notes = NOTE;
    end
elseif strcmp(instrmt, 'clarinet')==1 % synthesize clarinet notes
    for i = 1:N
        [NOTE, t, f, a] = wind_instrument_note('clarinet',Fs, dur(i), 1, freq(i));
        if size(NOTE,1)==1;
            NOTE = NOTE';
        end
        out(i).notes = NOTE;
    end
elseif strcmp(instrmt, 'oboe')==1 % synthesize oboe notes
    for i = 1:N
        [NOTE, t, f, a] = wind_instrument_note('oboe',Fs, dur(i), 1, freq(i));
        if size(NOTE,1)==1;
            NOTE = NOTE';
        end
        out(i).notes = NOTE;
    end
elseif strcmp(instrmt, 'bassoon')==1 % synthesize bassoon notes
    for i = 1:N
        [NOTE, t, f, a] = wind_instrument_note('bassoon',Fs, dur(i), 1, freq(i));
        if size(NOTE,1)==1;
            NOTE = NOTE';
        end
        out(i).notes = NOTE;
    end
elseif strcmp(instrmt, 'flute')==1 % synthesize flute notes
    for i = 1:N
        [NOTE, t, f, a] = wind_instrument_note('flute',Fs, dur(i), 1, freq(i));
        if size(NOTE,1)==1;
            NOTE = NOTE';
        end
        out(i).notes = NOTE;
    end
elseif strcmp(instrmt, 'piccolo')==1 % synthesize piccolo notes
    for i = 1:N
        [NOTE, t, f, a] = wind_instrument_note('piccolo',Fs, dur(i), 1, freq(i));
        if size(NOTE,1)==1;
            NOTE = NOTE';
        end
        out(i).notes = NOTE;
    end
elseif strcmp(instrmt, 'sax')==1 % synthesize saxophone notes
    for i = 1:N
        [NOTE, t, f, a] = wind_instrument_note('sax',Fs, dur(i), 1, freq(i));
        if size(NOTE,1)==1;
            NOTE = NOTE';
        end
        out(i).notes = NOTE;
    end
elseif strcmp(instrmt, 'trumpet')==1 % synthesize trumpet notes
    for i = 1:N
        [NOTE, t, f, a] = wind_instrument_note('trumpet',Fs, dur(i), 1, freq(i));
        if size(NOTE,1)==1;
            NOTE = NOTE';
        end
        out(i).notes = NOTE;
    end
elseif strcmp(instrmt, 'tuba')==1 % synthesize tube notes
    for i = 1:N
        [NOTE, t, f, a] = wind_instrument_note('tuba',Fs, dur(i), 1, freq(i));
        if size(NOTE,1)==1;
            NOTE = NOTE';
        end
        out(i).notes = NOTE;
    end
elseif strcmp(instrmt, 'trombone')==1 % synthesize trombone notes
    for i = 1:N
        [NOTE, t, f, a] = wind_instrument_note('trombone',Fs, dur(i), 1, freq(i));
        if size(NOTE,1)==1;
            NOTE = NOTE';
        end
        out(i).notes = NOTE;
    end
    
end

end

