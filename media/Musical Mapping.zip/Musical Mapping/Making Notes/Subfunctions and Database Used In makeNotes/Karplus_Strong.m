function note = Karplus_Strong(A, alpha, duration, Fs)
%
% This function employs the Karplus-Strong algorithm to synthesize 
% plucked-string sound. With alpha = 0.5, we can synthesize a guitar string.  
% 
% Input
% A         : frequency
% alpha     : gain
% duration  : duration
% Fs        : sampling rate
%
% Output
% note      : the synthesized sound
%
F = linspace(1/Fs, 1000, 2^12); % frequency vector
x = zeros(Fs*duration, 1); % input to filter
delay = round(Fs/A); % compute closest integer delay

N = delay + 2; % length of coefficient vector a 
b = zeros(1, 1); % set up coefficient vector b
b(1)= 1;
a = zeros(N, 1); % set up coefficient vector a
a(1) = 1;
a(N-1) = -alpha;
a(N) = -alpha; 

Hd = dfilt.df1(b, a); % create filter object with coeffs (a,b)

% populate states with random numbers
Hd.ResetBeforeFiltering = 'off';
Hd.States.Numerator = rand(length(b)-1, 1);
Hd.States.Denominator = rand(length(a)-1, 1);

% filter signal to synthesize note (duration seconds long)
note = filter(Hd, x);
end

