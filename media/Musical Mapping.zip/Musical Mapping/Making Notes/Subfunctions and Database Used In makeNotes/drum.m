function note = drum(freqHz, dur, fs, b, S)
%
% This function utilizes the modified Drum algorithm to synthesize 
% drum-like sound. 
%
% Input
% freqHz   : frequency
% dur      : duration
% fs       : sampling rate
% b        : blend factor (0 <= b <= 1)
% S        : stretch factor (S > 1)
%
% Output
% note     : the synthesized drum-like sound
%
N = fs/freqHz; % the delay
N = floor(N);

% Set up random wavetable load
x = 2*rand(1,N);
x = x - mean(x);

y = [zeros(1,N+1)]; % initialize y

iterations = round(dur*fs); % iteration determines the length of output 
if iterations > length(x)
    diff = iterations - length(x);
    x = [x zeros(1,diff)];
end

% Filtering using probabilistic recurrence relation
out = 0;
note = 0;
lengthYOffset = length(y)-1;
for i=1:iterations % Set up
    if rand()<b/S
    out = x(i) + 0.5*(y(N) + y(N+1)); % filter signal
    elseif rand() < b/S + (1-b)/S
    out = x(i) - 0.5*(y(N) + y(N+1)); % filter signal
    elseif rand() < b/S + (1-b)/S + b*(1-1/S)
        out = x(i) + y(N);
    else
        out = x(i) - y(N);
    end
    y = [out, y(1:lengthYOffset)]; % update delay line
    note = [note out];
end
note = note';
% Play sound and plot
% ---------------------------------------------------------------------------
%plot(note), grid on
end