
function note = modifiedKS(freqHz, dur, fs, S)
%
% This function utilizes the modified Karplus-Strong algorithm to synthesize 
% plucked-string or woodwind-like sound. 
%
% Input
% freqHz   : frequency
% dur      : duration
% fs       : sampling rate
% S        : stretch factor (S > 1)
%
% Output
% note     : the synthesized sound
%
N = fs/freqHz; % the delay
N = floor(N);

x = Karplus_Strong(freqHz, 0.5, N/fs, fs); % Use guitar sound as 
                                            % a wavetable load
x = x';

y = [zeros(1,N+1)]; % initialize y

iterations = round(dur*fs); % iterations determines the length of output
if iterations > length(x)
    diff = iterations - length(x);
    x = [x zeros(1,diff)];
end

% Filtering using probabilistic recurrence relation
out = 0;
note = 0;
lengthYOffset = length(y)-1;
for i=1:iterations
    if rand()<1/S
    out = x(i) + 0.5*(y(N) + y(N+1)); % filter signal
    else
        out = x(i) + y(N);
    end
    y = [out, y(1:lengthYOffset)]; % update delay line
    note = [note out];
end
note = note';
% Play sound and plot
% ---------------------------------------------------------------------------
%plot(note), grid on
%soundsc(note,fs)
end
