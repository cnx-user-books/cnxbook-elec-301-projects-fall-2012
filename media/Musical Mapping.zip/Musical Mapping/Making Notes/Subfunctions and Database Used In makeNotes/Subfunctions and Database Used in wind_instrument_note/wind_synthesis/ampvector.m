function ampt = ampvector(amptype, t, curvetype, attacktime, points, transtypes, verbose)
% instantaneous amplitude evolution according to a certain function amptype
maxamp = 1;
% check attacktime
if (attacktime > 0.9); attacktime=0.2; disp('WARNING: attack time larger than 90%, forced to 20\%'); end;
% attack point
k = find(t > attacktime * t(end), 1, 'first');

	switch amptype
	   case {'constant'}
	      if verbose >= 1; disp('amplitude function is constant'); end;
	      ampt = ones(1,length(t));
     
	   case {'attack-only'}
		if verbose >= 1; disp(['amplitude function is ' amptype ' ' curvetype]); end;
		switch curvetype
			case {'linear'}
				ampt = maxamp * 1/(t(end)-t(1)).*(t-t(1));
			case {'exponential'}
				ampt = maxamp * 1/(t(end)-t(1))^2.*(t-t(1)).^2;
			case {'hann-window'}
			   	ampt = maxamp * hann(2*length(t))';
				ampt = ampt(1:end/2);
			otherwise
				disp('WARNING: unknown curve type, forced to linear')
				ampt = ampvector(amptype, t, 'linear', attacktime, verbose);
		end
		
	   case {'decay-only'}
		if verbose >= 1; disp(['amplitude function is ' amptype ' ' curvetype]); end;
		switch curvetype
			case {'linear'}
				ampt = maxamp * -1/(t(end)-t(1)).*(t-t(1)) + maxamp;
			case {'exponential'}
				ampt = maxamp * -1/(t(end)-t(1))^(1/2).*(t-t(1)).^(1/2) + maxamp;
			case {'hann-window'}
			   	ampt = maxamp * hann(2*length(t))';
				ampt = ampt(end/2+1:end);
			otherwise
				disp('WARNING: unknown curve type, forced to linear')
				ampt = ampvector(amptype, t, 'linear', attacktime, verbose);
		end
				
	   case {'attack-decay'}
		if verbose >= 1; disp(['amplitude function is ' amptype ' ' curvetype]); end;
		switch curvetype 
            case {'linear'}
				ampt = maxamp * [1/(t(k)-t(1)).*(t(1:k)-t(1)) -1/(t(end)-t(k+1)).*(t(k+1:end)-t(k+1)) + maxamp];
			case {'exponential'}
				ampt = maxamp * [1/(t(k)-t(1))^2.*(t(1:k)-t(1)).^2 -1/(t(end)-t(k+1))^(1/2)*(t(k+1:end)-t(k+1)).^(1/2)+maxamp];
			case {'hann-window'}
			   	ampt = maxamp * hann(length(t))';
			otherwise
				disp('WARNING: unknown curve type, forced to linear')
				ampt = ampvector(amptype, t, 'linear', attacktime, verbose);
        end
        
       case {'piecewise'}
         if verbose >= 1; disp(['amplitude function is ' amptype]); end;     
         ampt = piecewiseampvector(points, transtypes, t, verbose); 
         
	   case {'adsr'}
		if verbose >= 1; disp(['amplitude function is ' amptype ' ' curvetype]); end;
		if (attacktime >= 0.4)
			attacktime = 0.2;
			k = find(t > attacktime * t(end), 1, 'first');
			disp('WARNING: attack time too large, forced to 20%'); 
		end;
		d = floor(3*k/2);
		s = length(t)-k;
		switch curvetype
			case {'linear'};
				ampt = [maxamp/(t(k)-t(1)).*(t(1:k)-t(1)) (2*maxamp/3-maxamp)/(t(d)-t(k+1)).*(t(k+1:d)-t(k+1))+maxamp 2*maxamp/3*ones(1,length(d+1:s)) -2*maxamp/3/(t(end)-t(s+1)).*(t(s+1:end)-t(s+1))+2*maxamp/3];
			case {'exponential'}
				ampt = [maxamp/(t(k)-t(1))^2.*(t(1:k)-t(1)).^2 (2*maxamp/3-maxamp)/(t(d)-t(k+1))^2.*(t(k+1:d)-t(k+1)).^2+maxamp 2*maxamp/3*ones(1,length(d+1:s)) -2*maxamp/3/(t(end)-t(s+1))^2.*(t(s+1:end)-t(s+1)).^2+2*maxamp/3];
			case {'hann-window'}
				ampt = hann(2*length(t(1:k)))';
				atmp = maxamp/3*hann(2*length(t(k+1:d)))';
				ampt = [maxamp*ampt(1:k) atmp(length(t(k+1:d))+1:end)+2*maxamp/3 2*maxamp/3*ones(1,length(t(d+1:s))) 2*maxamp/3*ampt(k+1:end)];
			otherwise
				disp('WARNING: unknown curve type, forced to linear')
				ampt = ampvector(amptype, t, 'linear', attacktime, verbose);
		end
   
	   otherwise
	      disp('WARNING: unknown amptype, forced to constant')
	      ampt = ampvector('constant', t, curvetype, attacktime, verbose);
	end

end
