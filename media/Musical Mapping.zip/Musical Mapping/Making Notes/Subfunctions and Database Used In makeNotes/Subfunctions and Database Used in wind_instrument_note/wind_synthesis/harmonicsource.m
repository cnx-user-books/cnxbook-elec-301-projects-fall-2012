function [d, t, f, a, p] = harmonicsource(fs, dur, nharm, f0, varargin)
% Roughly simulates an harmonic sound source
% input:
% 	fs    - sampling frequency
% 	dur   - duration in seconds
%	f0    - fundamental frequency: 
%		f0(1) = initial f0
%		f0(2) = final  f0 (can be omitted if no evolution in f0 is desired)
%	nharm - number of harmonics
%
% additional options to be controlled (defaults in parenthesis): 
%       'verbose' (0)             : 0 - no messages, 1 - warnings and informative messages, 2 - plots       
%        'f0type' ('constant')    : type of function that models the evolution of f0 in time, from f0(1) up to f0(2)
%                                   other options : 'linear', 'quadratic', 'sinusoidal'
%    'amplitudes' (ones(nharm,1)) : vector of relative amplitudes of harmonics (they are normalized by default)
% 'inharmonicity' (zero)          : inharmonicity factor, used as fn = n * f0  * sqrt(1 + (n^2-1) * inharmonicity)
%                                   based on A. P. Klapuri.  Multiple fundamental frequency estimation based on 
%                                                            harmonicity and spectral smoothness. IEEE Trans. Speech 
%                                                            and Audio Proc., 11(6), 804-816, 2003
%       'amptype' ('constant')    : type of function that models the amplitude evolution of the harmonics
%                                   other options: 
%                                                 'attack-only' - amplitude grows monotonously 
%                                                  'decay-only' - amplitude falls monotonously 
%                                                'attack-decay' - amplitude grows monotonously during the attack time 
%                                                                 then falls monotonously the rest of the time
%                                                        'adsr' - attack-decay-sustain-release type of evolution
%                                                   'piecewise' - amplitude specified by a set of points and type of 
%                                                                 transition parameters:
%                                                                 points - are [t, x] pairs (t - time instant, x - amplitude)
%                                                                 transtype = 0 - straight line
%                                                                 transtype < 0 - exponential curve
%                                                                 transtype > 0 - inverse exponential curve
%                                                                   
%     'curvetype' ('linear')      : type of curve used for non-constant amplitude evolution 
%                                   other options: 'exponential', 'hann-window'
%
%    'attacktime' (0.2)           : attacktime as a percentaje of the duration
%                                   can't be greater than 0.9 in attack-decay mode, or greater than 0.4 in 'adsr' mode
%
%      'ampscale' (1)             : amplitude scale factor that specifies the maximum value of the output signal
%                                   if set to 0 no amplitude normalization is done but clipping can occur
%
% output:
% 	d   - audio signal, sum of harmonics
%	t   - vector of sample time instants
%	f   - matrix where each row is the frequency evolution of each harmonic
%	a   - matrix where each row is the amplitude evolution of each harmonic
%	p   - matrix where each row is the phase evolution of each harmonic
%
%
% examples:
%
% [d, t, f, a] = harmonicsource(8000, 1, 4, [500, 800],'f0type', 'linear', 'amplitudes', [0.5, 0.25, 0.20, 0.05])
% four harmonics, linear evolution from 500 to 800 Hz, amplitudes set by user, constant amplitudes, no messages
%
% [d, t, f, a] = harmonicsource(8000, 1, 6, 500, 'f0type', 'constant', 'inharmonicity', 0.001, 'verbose', 2)
% six harmonics, constant f0 of 500 Hz, inharmonicity factor of 0.001, constant amplitudes
%
% [d, t, f, a] = harmonicsource(8000, 1, 6, 500, 'inharmonicity', 0.001, 'amptype', 'attack-decay', 'attacktime', 0.1, 'verbose', 2)
% same situation of the last example but amplitudes evolve in an attack-decay fashion with linear curves and 10% attack
%
% [d, t, f, a] = harmonicsource(8000, 1, 8, [500, 200],'f0type', 'quadratic', 'verbose', 1)
% eight harmonics, quadratic evolution from 500 to 100 Hz, constant amplitudes, some messages are displayed (e.g f0type)
%
% [d, t, f, a] = harmonicsource(8000, 1, 8, [500, 200],'f0type', 'quadratic', 'amptype', 'adsr', 'curvetype', 'hann-window')
% same situation of the last example but amplitudes evolve in an adsr fashion using a hann-window type of curve
%
% [d, t, f, a] = harmonicsource(8000, 1, 7, [500, 6],'f0type', 'sinusoidal', 'verbose', 2);
% seven harmonics, sinusoidal evolution of 6 Hz centered at 500 Hz, spectrogram and waveform are plotted
%
% Notice that if aliasing occurs a warning is displayed (if verbose mode >= 1)

%% parameters
if nargin < 1;    fs = 8000; end
if nargin < 2;   dur = 1;    end
if nargin < 3; nharm = 4;    end
if nargin < 4;    f0 = 100;  end

% parse out the optional arguments
[verbose, f0type, amplitudes, inharmonicity, amptype, curvetype, attacktime, points, transtypes, ...
 ampscale, vib_depth, vib_depth_points, vib_depth_transtypes, vib_rate_points, vib_rate_transtypes, ...
 randomphase, synthesize_only_harmonics, harmonics, f0t, phi] = ... 
process_options(varargin, 'verbose', 0, 'f0type', 'constant', 'amplitudes', ones(nharm,1), ... 
'inharmonicity', 0, 'amptype', 'constant', 'curvetype', 'linear', 'attacktime', 0.2, ... 
'points', [ 0 0; 0.1 1; 0.8 0.5; 1 0], 'transtypes', [-1 -4 -1], 'ampscale', 1, 'vib_depth', 0.3, ...
'vib_depth_points', [0 0.1; (0.8*dur) 1; dur 0.7], 'vib_depth_transtypes', [0 0], ...
'vib_rate_points', [0 2.5+rand; dur 4.5+rand], 'vib_rate_transtypes', 0, 'randomphase', 0, ...
'synthesize_only_harmonics', 0, 'harmonics', (1:1:nharm), 'f0t', 0, 'phi', 0);
% 'vib_rate_points', [0 2.5+rand; dur 4.5+rand], 'vib_rate_transtypes', 0, 'randomphase', 0, ...


%% compute
% time
t = 0:1/fs:dur;
%t = t(1:1:end-1);
%t = 1/fs:1/fs:dur;
% fundamental frequency evolution
if ~synthesize_only_harmonics
    [f0t, phi] = f0vector(f0, f0type, t, verbose, fs, vib_depth, vib_depth_points, vib_depth_transtypes, vib_rate_points, vib_rate_transtypes);
end
% inharmonic factors for each harmonic
inharmonFactors = sqrt(1 + ((1:1:nharm).^2 - 1) * inharmonicity);
% instantaneous frequency evolution of each harmonic
f = (harmonics .* inharmonFactors)' * f0t;
% phase evolution of each harmonic
p = (harmonics .* inharmonFactors)' * phi;
% amplitude evolution function
ampt = ampvector(amptype, t, curvetype, attacktime, points, transtypes, verbose);
% amplitudes of each harmonic
if length(amplitudes) < nharm
	amplitudes = ones(nharm,1);
	if verbose >= 1; disp('WARNING: not enough amplitude values, forced them all to unity'); end;
end
% amplitude evolution of each harmonic
a = amplitudes(:) * ampt;

% random phase
if (randomphase)
    p = p + rand;
%     for i=1:nharm
%         p(i,:) = p(i,:) + rand;
%     end
end

% waveform obtained as the sum of harmonics
if (nharm > 1)
	d = sum(a .* sin( 2 * pi * p));
else
  	d = a(1,:) .* sin( 2 * pi * p);
end

% amplitude scale factor
if (ampscale > 1 || ampscale < 0); 
    ampscale = 1;
    if verbose >= 1; disp('WARNING: ampscale must be in the range 0 <= ampscale <= 1, forced to 1'); end;
end
if ampscale ~= 0 % if set to 0 no normalization is done, but clipping can occur!
    ampfactor = ampscale / max(abs(d));
    d = d * ampfactor;
    a = a * ampfactor;
end

% aliasing warning
if verbose >= 1; if max(max(nharm*f0t)) > fs/2; disp('WARNING: aliasing!'); end; end;
% clipping warning
if verbose >= 1; if max(abs(d)) > 1; disp('WARNING: clipping!'); end; end;

%% plots
if (verbose >= 2)
	figure; 
	subplot(3,1,1:2)
	t_window = 0.025;
	window = floor(t_window * fs);
	noverlap = floor(window / 2);
	nfft = window * 2;
	[S,F,T] = spectrogram(d,window,noverlap,nfft,fs);
	imagesc(T,F,20*log10(abs(S)+1))
	colormap('gray');set(gca,'YDir','normal')
    hold on
    plot(t,f','k')
    hold off  
    title('Spectrogram and frequency evolution of each harmonic');xlabel('Time (s)');ylabel('Frequency (Hz)');
	subplot(3,1,3)
	plot(t,d,'k');
	title('Waveform');xlabel('Time (s)');ylabel('Amplitude'); axis tight

% 	figure; 
% 	subplot(3,1,1:2)
% 	plot(t,f','k')
% 	grid
% 	ylim([0, fs/2])
% 	title('Frequency evolution of each harmonic');xlabel('Time (s)');ylabel('Frequency (Hz)');
% 	subplot(3,1,3)
% 	plot(t,d,'k');
% 	title('Waveform');xlabel('Time (s)');ylabel('Amplitude'); axis tight

	figure; 
	subplot(3,1,1:2)
	plot3(t,f,a,'k')
	grid; ylim([0, fs/2]); view([60 20])
	title('Frequency and amplitude evolution of each harmonic');xlabel('Time (s)');ylabel('Frequency (Hz)');zlabel('Amplitude');
	subplot(3,1,3)
	plot(t,d,'k');
	title('Waveform');xlabel('Time (s)');ylabel('Amplitude'); axis tight
end

end % end function

