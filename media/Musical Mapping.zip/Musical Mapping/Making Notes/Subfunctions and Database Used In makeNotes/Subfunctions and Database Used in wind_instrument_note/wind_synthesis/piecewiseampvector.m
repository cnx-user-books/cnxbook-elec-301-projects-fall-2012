function ampt = piecewiseampvector(points, transtypes, t, verbose, normalize)
% instantaneous amplitude evolution according to a certain piecewise
% function, specified by a sucesion of points and transition parameters
% the points are connected according to a curve whose type is determined 
% by the transition parameters:
%                               transtype = 0 - straight line
%                               transtype < 0 - exponential curve
%                               transtype > 0 - inverse exponential curve
% points are [t, x] pairs (t - time instant, x - amplitude)
% normalize - whether to normalize amplitude to 1
%
% See sec 3.2.8 Amplitude Control from "Computer Music: Synthesis Composition
% and Performance" C. Dodge and T.A. Jerse

% parameters
if nargin < 4;   verbose = 1;  end
if nargin < 5; normalize = 1;  end

ampt = zeros(size(t));
N_points = length(points); 

if (N_points ~= length(transtypes)+1)
    transtypes = zeros(1, N_points-1);
    if (verbose); disp('WARNING: different number of points and transition parameters, forced to straight lines'); end;
end

t_p = points(:,1);
x_p = points(:,2);

for i = 1:N_points-1
    indices = find((t >= t_p(i)) & (t <= t_p(i+1)));
    t_seg = t(indices);
    if (transtypes(i) ~= 0) 
        num = 1 - (1 - exp( (t_seg - t_p(i)) / (t_p(i+1) - t_p(i))  * transtypes(i)));
        den = 1 - exp(transtypes(i));
    else
        num = (t_seg - t_p(i)) / (t_p(i+1) - t_p(i));    
        den = 1;
    end
    ampt(indices) = x_p(i) + (x_p(i+1) - x_p(i)) * num / den;
end

if (max(ampt) > 1 && normalize)
    ampt = ampt / max(ampt);
end

end

