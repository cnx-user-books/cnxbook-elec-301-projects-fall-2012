function [f0t, phi] = f0vector(f0, f0type, t, verbose, fs, vib_depth, vib_depth_points, vib_depth_transtypes, vib_rate_points, vib_rate_transtypes)
% instantaneous frequency evolution according to a certain function f0type
	switch f0type
	   case {'constant'}
	      if verbose >= 1; disp('f0 function is constant'); end;
	      phi = f0(1) * t;
	      f0t = f0(1) * ones(1,length(t));
	      
	   case {'linear'}
	      % check if f0 has two items
	      if (length(f0) >= 2)
	      	if verbose >= 1; disp('f0 function is linear'); end;
		phi = (f0(2)-f0(1))/(t(end)-t(1))*((t.^2-t(1)^2)/2+t(1)*(t-t(1)))+f0(1)*(t-t(1));
	      	f0t = (f0(2)-f0(1))/(t(end)-t(1))*(t-t(1))+f0(1);
              else
	      	disp('WARNING: missing f0 value, forced to constant')
	      	[f0t, phi] = f0vector(f0, 'constant', t, verbose);
	      end

	   case 'quadratic'
   	      % check if f0 has two items
	      if (length(f0) >= 2)
	      	if verbose >= 1; disp('f0 function is quadratic'); end;
		f0t = (f0(2)-f0(1))/(t(end)-t(1))^2*((t-t(1)).^2)+f0(1);
		phi = (f0(2)-f0(1))/(t(end)-t(1))^2*((t.^3-t(1)^3)/3-t(1)*(t.^2-t(1))+t(1)^2*(t-t(1)))+f0(1)*(t-t(1));
              else
	      	disp('WARNING: missing f0 value, forced to constant')
	      	[f0t, phi] = f0vector(f0, 'constant', t, verbose);
	      end

	   case 'sinusoidal'
      	      % check if f0 has two items
	      if (length(f0) >= 2) %#ok<ALIGN>
	      	if verbose >= 1; disp('f0 function is sinusoidal'); end;
		    phi = f0(1)*(1-2^(1/12))/(2*pi*f0(2))*(-cos(2*pi*f0(2)*t)+cos(2*pi*f0(2)*t(1)))+f0(1)*(t-t(1));
	      	f0t = f0(1)*(1-2^(1/12))*sin(2*pi*f0(2)*t)+f0(1);
          else
	      	disp('WARNING: missing f0 value, forced to constant')
	      	[f0t, phi] = f0vector(f0, 'constant', t, verbose);
          end
          
        case 'vibrato'
            if verbose >= 1; disp('f0 function is vibrato'); end;
            % vibrato depth
            vib_depth_vector = (vib_depth*f0(1)/100) * piecewiseampvector(vib_depth_points, vib_depth_transtypes, t, verbose, 0);
            % vibrato rate
            % vib_rate_vector  = 10 * piecewiseampvector(vib_rate_points, vib_rate_transtypes, t, verbose);
            vib_rate_vector  = piecewiseampvector(vib_rate_points, vib_rate_transtypes, t, verbose, 0);
            % frequency evolution
            f0t = f0(1) + vib_depth_vector .* sin(2*pi*vib_rate_vector.*t);
            % phase evolution
            phi = cumsum(f0t)/fs;
     
	   otherwise
	      disp('WARNING: unknown f0 function, forced to constant')
	      f0t = f0vector(f0, 'constant', t, verbose);
	end

end
