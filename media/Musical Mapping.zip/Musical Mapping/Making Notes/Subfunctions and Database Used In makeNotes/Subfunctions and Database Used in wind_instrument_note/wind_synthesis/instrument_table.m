function amplitudes = instrument_table(instrument, f0)

if strcmp(instrument, 'horn')

    % amplitudes of frequency partials for 8 different f0 ranges
    amplitudes1 = [6.236 12.827 21.591 11.401 3.570 2.833 3.070 1.053 0.773 1.349 0.819 0.369 0.362 0.165 0.124 0 0.026 0.042];
    amplitudes2 = [3.236  6.827  5.591  2.401 1.870 0.733 0.970 0.553 0.373 0.549 0.319 0.119 0.092 0.045 0.034];
    amplitudes3 = [5.019  4.281  2.091  1.001 0.670 0.233 0.200 0.103 0.073 0.089 0.059 0.029];
    amplitudes4 = [4.712  1.847  0.591  0.401 0.270 0.113 0.060 0.053 0.023];
    amplitudes5 = [1.512  0.247  0.121  0.101 0.030 0.053 0.030]; 
    amplitudes6 = [0.412  0.087  0.071  0.021];
    amplitudes7 = [0.309  0.067  0.031];
    amplitudes8 = [0.161  0.047];

    % determine which amplitudes of frequency partials to use according to f0
    if     f0 < 85
        amplitudes = amplitudes1;
    elseif f0 < 114
        amplitudes = amplitudes2;
    elseif f0 < 153
        amplitudes = amplitudes3;
    elseif f0 < 204
        amplitudes = amplitudes4;
    elseif f0 < 272
        amplitudes = amplitudes5;
    elseif f0 < 364
        amplitudes = amplitudes6;
    elseif f0 < 486
        amplitudes = amplitudes7;
    else
        amplitudes = amplitudes8;
    end

elseif strcmp(instrument, 'clarinet')

    % amplitudes of frequency partials for 6 different f0 ranges
    amplitudes1 = [ 0.0   0.389 0.029 0.226 0.034 0.449 0.168 0.480 0.089 0.099 0.040 0.061 0.031 0.079 0.040 0.062 0.063 0.0   0.026 0.022 0.044 0.0 0.034 0.0 0.020]; 
    amplitudes2 = [ 0.0   0.560 0.035 0.304 0.122 0.397 0.055 0.141 0.038 0.052 0.022 0.027 0.026 0.0   0.038 0.076 0.046 0.029];  
    amplitudes3 = [ 0.061 0.628 0.231 1.161 0.201 0.328 0.154 0.072 0.186 0.133 0.309 0.071 0.098 0.114 0.027 0.057 0.022 0.042 0.023];
    amplitudes4 = [ 0.045 1.408 0.842 0.574 0.124 0.158 0.079 0.185 0.076 0.047 0.059 0.039 0.033];
    amplitudes5 = [ 0.206 0.302 0.052 0.069 0.072 0.032 0.031];
    amplitudes6 = [ 0.155 0.305 0.322 0.048 0.061 0.025];

    % determine which amplitudes of frequency partials to use according to f0
    if     f0 < 181
        amplitudes = amplitudes1;
    elseif f0 < 259
        amplitudes = amplitudes2;
    elseif f0 < 363
        amplitudes = amplitudes3;
    elseif f0 < 501
        amplitudes = amplitudes4;
    elseif f0 < 685
        amplitudes = amplitudes5;
    else
        amplitudes = amplitudes6;
    end

elseif strcmp(instrument, 'oboe')
    
    % amplitudes of frequency partials for 4 different f0 ranges
    amplitudes1 = [ 0.929 0.953 0.881 1.443 0.676 0.257 0.198 0.100 0.081 0.113 0.049 0.092 0.071 0.038];
    amplitudes2 = [ 1.460 2.713 1.360 1.192 0.615 0.256 0.228 0.320 0.158 0.063 0.039 0.062 ];%0.047]; 
    amplitudes3 = [ 1.386 1.370 0.360 0.116 0.106 0.201 0.037 0.019]; 
    amplitudes4 = [ 0.646 0.034 0.136 0.026];

    % determine which amplitudes of frequency partials to use according to f0
    if     f0 < 355
        amplitudes = amplitudes1;
    elseif f0 < 503
        amplitudes = amplitudes2;
    elseif f0 < 888
        amplitudes = amplitudes3;
    else
        amplitudes = amplitudes4;
    end

elseif strcmp(instrument, 'bassoon')
        
    % amplitudes of frequency partials for 6 different f0 ranges
    amplitudes1 = [ 1.339 1.324 1.567 1.602 1.777 1.143 0.746 1.231 1.618 0.823 0.572 0.282 0.421 0.419 0.470 0.126 0.722 0.609 0.402 0.273 0.272 0.351 0.152 0.087 0.067 0.189 0.172 0.227 0.152 0.114 0.060 0.059 0.069 0.084 0.073 0.054 0.025 0.038 0.070 0.064 0.055 0.032 0.027 0.051 0.034 0.041 0.056 0.026 0.0 0.0 0.0 0.024];
    amplitudes2 = [ 1.348 2.896 4.100 6.159 3.342 0.109 1.577 0.756 0.745 0.781 1.175 1.204 0.572 1.003 0.430 0.166 0.488 0.212 0.142 0.077 0.047 0.059 0.094 0.048 0.041 0.035 0.022 0.062 0.167 0.200 0.100 0.037 0.023 0.0   0.061 0.030 0.100 0.125 0.098 0.053 0.073 0.073 0.063 0.046 0.0   0.030 0.042]; 
    amplitudes3 = [ 6.037 6.737 6.752 1.300 0.536 0.339 1.719 1.347 0.866 0.753 0.238 0.346 0.169 0.190 0.063 0.084 0.258 0.181 0.076 0.069 0.087 0.085 0.116 0.107 0.195 0.096 0.086 0.093 0.036 0.074 0.052 0.052 0.040 0.046 0.039]; 
    amplitudes4 = [ 3.912 1.245 0.301 0.537 0.827 0.161 0.258 0.205 0.129 0.060 0.080 0.131 0.094 0.054 0.057 0.061 0.054 0.026 0.021 0.024 0.024];
    amplitudes5 = [ 4.071 1.026 0.618 0.186 0.153 0.026 0.056 0.070 0.040 0.026 0.026];
    amplitudes6 = [ 0.759 0.568 0.374 0.052]; 

    % determine which amplitudes of frequency partials to use according to f0
    if     f0 < 86
        amplitudes = amplitudes1;
    elseif f0 < 129
        amplitudes = amplitudes2;
    elseif f0 < 194
        amplitudes = amplitudes3;
    elseif f0 < 291
        amplitudes = amplitudes4;
    elseif f0 < 436
        amplitudes = amplitudes5;
    else
        amplitudes = amplitudes6;
    end

elseif strcmp(instrument, 'flute')
    
    % amplitudes of frequency partials for 3 different f0 ranges
    amplitudes1 = [ 0.260 0.118 0.085 0.017 0.014]; 
    amplitudes2 = [ 0.090 0.078 0.010 0.013];
    amplitudes3 = [ 0.029 0.011];

    % determine which amplitudes of frequency partials to use according to f0
    if     f0 < 611
        amplitudes = amplitudes1;
    elseif f0 < 1050
        amplitudes = amplitudes2;
    else
        amplitudes = amplitudes3;
    end

elseif strcmp(instrument, 'piccolo')
    
    % amplitudes of frequency partials for 5 different f0 ranges
    amplitudes1 = [ 0.151 0.234 0.145 0.039 0.022 0.014 0.012 0.022];
    amplitudes2 = [ 0.078 0.159 0.039 0.028];
    amplitudes3 = [ 0.040 0.079 0.020 0.012];
    amplitudes4 = [ 0.030 0.015];
    amplitudes5 = [ 0.019 0.009];

    % determine which amplitudes of frequency partials to use according to f0
    if     f0 < 843
        amplitudes = amplitudes1;
    elseif f0 < 1202
        amplitudes = amplitudes2;
    elseif f0 < 1696
        amplitudes = amplitudes3;
    elseif f0 < 2400
        amplitudes = amplitudes4;
    else
        amplitudes = amplitudes5;
    end

elseif strcmp(instrument, 'sax')
    
    % amplitudes of frequency partials for 7 different f0 ranges
    amplitudes1 = [ 3.615 2.627 2.292 1.164 3.599 5.725 2.803 0.581 0.318 0.139 0.654 0.640 0.445 0.605 0.547 0.483 0.222 0.175 0.053 0.165 0.118 0.215 0.150 0.502 0.362 0.472 0.366 0.448 0.608 0.319 0.311 0.316 0.264 0.098 0.233 0.170 0.060 0.206 0.102 0.122 0.043 0.040 0.0  0.0 0.023 0.0 0.022 0.0 0.028 0.030 0.0 0.035 0.050 0.0 0.0 0.031 0.0 0.0 0.024 0.0 0.0 0.028 0.0 0.0 0.0 0.0 0.0 0.023 0.0 0.025];
    amplitudes2 = [ 0.651 0.478 2.867 2.561 0.330 0.210 0.570 0.560 0.428 0.353 0.114 0.092 0.222 0.375 0.484 0.359 0.306 0.243 0.184 0.181 0.189 0.171 0.164 0.103 0.114 0.067 0.055 0.0   0.0   0.021 0.0   0.0   0.0   0.0   0.0   0.0   0.026];
    amplitudes3 = [ 1.053 0.410 0.257 0.340 0.199 0.265 0.396 0.244 0.281 0.405 0.196 0.240 0.131 0.065 0.027 0.039 0.036 0.038 0.049 0.034 0.043 0.045 0.055 0.062 0.048 0.030];
    amplitudes4 = [ 0.266 0.461 0.203 0.556 0.307 0.358 0.389 0.612 0.252 0.207 0.053 0.042 0.032 0.061 0.086 0.121 0.132 0.095 0.079 0.042 0.031 0.022];
    amplitudes5 = [ 0.099 0.376 0.095 0.040 0.094 0.097 0.045 0.027 ];
    amplitudes6 = [ 0.041 0.158 0.227 0.072];
    amplitudes7 = [ 0.168 0.144 0.096];
    
    % determine which amplitudes of frequency partials to use according to f0
    if     f0 <  77
        amplitudes = amplitudes1;
    elseif f0 < 138
        amplitudes = amplitudes2;
    elseif f0 < 215
        amplitudes = amplitudes3;
    elseif f0 < 308
        amplitudes = amplitudes4;
    elseif f0 < 555
        amplitudes = amplitudes5;
    elseif f0 < 924
        amplitudes = amplitudes6;
    else
        amplitudes = amplitudes7;
    end

elseif strcmp(instrument, 'trumpet')
    
    % amplitudes of frequency partials for 7 different f0 ranges
    amplitudes1 = [ 1.473 2.461 3.101 3.579 4.874 2.769 2.396 1.557 1.489 1.324 1.162 0.679 0.558 0.461 0.225 0.178 0.105 0.069 0.064 0.053 0.049 0.036 ];
    amplitudes2 = [ 1.428 2.825 2.654 2.688 1.464 1.520 1.122 0.940 0.738 0.495 0.362 0.237 0.154 0.154 0.101 0.082 0.054 0.038 0.036 ]; 
    amplitudes3 = [ 0.693 1.606 1.591 1.056 0.867 0.501 0.370 0.159 0.111 0.105 0.054 0.041 0.027 0.024 0.013 ];
    amplitudes4 = [ 1.167 1.178 0.611 0.591 0.344 0.139 0.090 0.057 0.035 0.029 0.022 0.020 0.014 ];  
    amplitudes5 = [ 0.972 0.710 0.389 0.200 0.112 0.065 0.032 0.026 ];
    amplitudes6 = [ 0.900 0.262 0.069];
    
    % determine which amplitudes of frequency partials to use according to f0
    if     f0 < 255
        amplitudes = amplitudes1;
    elseif f0 < 340
        amplitudes = amplitudes2;
    elseif f0 < 457
        amplitudes = amplitudes3;
    elseif f0 < 615
        amplitudes = amplitudes4;
    elseif f0 < 828
        amplitudes = amplitudes5;
    else
        amplitudes = amplitudes6;
    end

elseif strcmp(instrument, 'tuba')
    
    % amplitudes of frequency partials for 6 different f0 ranges
    amplitudes1 = [ 2.638 1.176 3.122 1.523 2.396 1.547 1.347 1.330 0.766 0.739 0.451 0.387 0.388 0.393 0.298 0.232 0.172 0.152 0.077 0.063 0.097 0.039 ]; 
    amplitudes2 = [ 3.183 3.822 2.992 2.243 1.999 1.053 0.742 0.501 0.377 0.369 0.288 0.288 0.216 0.130 0.105 0.069 0.021 ]; 
    amplitudes3 = [ 0.685 0.741 0.791 0.395 0.327 0.175 0.105 0.102 0.074 0.063 0.034 ];
    amplitudes4 = [ 0.329 0.939 0.593 0.240 0.100 0.095 0.082 0.028 ];  
    amplitudes5 = [ 1.072 0.537 0.351 0.185 0.054 0.024 ]; 
    amplitudes6 = [ 0.448 0.183 0.087 0.028 ];
    
    % determine which amplitudes of frequency partials to use according to f0
    if     f0 < 68
        amplitudes = amplitudes1;
    elseif f0 < 90
        amplitudes = amplitudes2;
    elseif f0 < 121
        amplitudes = amplitudes3;
    elseif f0 < 161
        amplitudes = amplitudes4;
    elseif f0 < 216
        amplitudes = amplitudes5;
    else
        amplitudes = amplitudes6;
    end  

elseif strcmp(instrument, 'trombone')
    
    % amplitudes of frequency partials for 9 different f0 ranges
    amplitudes1 = [ 6.250 9.625 15.625 16.500 19.875 18.125 16.875 46.500 48.000 66.125 74.375 47.125 44.500 32.625 45.000 54.750 56.500 47.875 47.500 36.625 39.750 44.500 37.875 33.875 32.625 23.875 29.125 29.500 28.125 29.625 22.250 24.750 38.125 36.625 30.375 23.125 19.625 18.750 16.750 19.750 15.875 14.250 13.875 12.000 13.000 11.125 13.000 9.875 9.750 9.000 8.875 9.000 7.125 7.875 7.625 6.500 5.375 6.000 6.000 4.250 4.625 4.625 4.375 3.750 4.000 3.875 3.125 3.250 3.500 3.125 3.000 2.875 3.125 2.625 2.750 2.500 2.750 2.750 2.125 1.625 1.750 2.125 1.875 1.875 1.875 1.625 1.500 1.500 1.500 1.375 1.375 1.250 1.250]; 
    amplitudes2 = [ 2.483 3.763 6.934 8.465 10.877 12.769 24.484 11.435 22.587 22.086 22.754 26.312 19.037 18.337 19.727 15.371 16.113 10.108 11.592 14.140 14.021 12.964 17.916 16.845 17.381 10.054 7.988 7.321 5.230 4.326 4.511 3.824 3.549 3.398 3.250 2.375 1.952 2.044 1.147 1.710 0.725 0.694 0.712 0.343 0.667 0.334 0.172 0.174 0.198 0.284 0.419 0.504 0.506 0.581 0.538 0.626 0.699 0.780 0.698 0.941 0.818 0.754 0.771 0.820 0.929 0.861 0.854 0.910 0.932 0.769 0.921 0.818 0.966 0.924 0.848 0.867 0.782 0.770 0.809 0.737 0.799 0.682 0.651 0.630 0.657 0.608 0.635 0.573 0.547 0.596 0.545 0.499 ]; 
    amplitudes3 = [ 2.288 3.627 3.741 6.847 4.659 6.059 5.318 4.141 4.906 3.447 2.506 3.988 2.800 4.306 2.447 2.200 1.376 1.541 1.647 1.035 1.106 0.765 0.682 0.718 0.553 0.435 0.459 0.259 0.282 0.141 0.224 0.188 0.188 0.141 0.153 0.106  0.099 0.082 0.072 0.059 0.074 0.048 0.042 0.041 0.038 0 0.026 0.027 0 0.021 0.021 ];
    amplitudes4 = [ 2.336 3.832 5.788 4.676 5.923 5.964 4.695 2.915 3.063 4.612 3.124 2.738 2.422 1.780 1.378 1.392 1.441 0.867 0.811 0.646 0.554 0.337 0.437 0.385 0.303 0.287 0.236 0.149 0.166 0.148 0.126 0.095 0.099 0.082 0.072 0.059 0.074 0.048 0.042 0.041 0.038 0 0.026 0.027 0 0.021 0.021 ];  
    amplitudes5 = [ 2.109 3.239 2.557 3.340 1.898 1.943 1.743 1.664 1.013 0.708 0.691 0.628 0.412 0.371 0.292 0.262 0.249 0.196 0.150 0.134 0.124 0.097 0.075 0.071 0.061 0.059 0.047 0.044 0.040 0.031 0.027 0.025 0.021 ]; 
    amplitudes6 = [ 1.701 2.444 2.824 1.432 1.976 1.645 1.270 0.745 0.567 0.533 0.346 0.184 0.201 0.153 0.108 0.097 0.086 0.075 0.059 0.048 0.043 0.038 0.030 ];
    amplitudes7 = [ 1.978 4.767 2.309 1.417 1.233 0.801 0.493 0.382 0.301 0.178 0.163 0.151 0.095 0.074 0.062 0.041 0.035 0.033 0.026 ];
    amplitudes8 = [ 1.020 0.700 0.441 0.292 0.240 0.139 0.087 0.084 0.062 0.045 0.032 0.030 0.025 ];
    amplitudes9 = [ 0.567 0.251 0.108 0.030 ];
    
    % determine which amplitudes of frequency partials to use according to f0
    if     f0 < 49
        amplitudes = amplitudes1;
    elseif f0 < 78
        amplitudes = amplitudes2;
    elseif f0 < 114
        amplitudes = amplitudes3;
    elseif f0 < 152
        amplitudes = amplitudes4;
    elseif f0 < 203
        amplitudes = amplitudes5;
    elseif f0 < 272
        amplitudes = amplitudes6;
    elseif f0 < 363
        amplitudes = amplitudes7;
    elseif f0 < 484
        amplitudes = amplitudes8;
    else
        amplitudes = amplitudes9;
    end   
    
end
    
end
