%% wind synthesis example program
clear all;
close all;
%% global parameters 
fs = 44100;
verbose = 0;
%% reverb paremeters
reverb = 1;    % whether to use reverb or not
delay  = 1.2;  % delay time
pr     = 0.25; % percent of reverberated signal
%% output filename prefix
out = 'wind_synthesis-test';
%% score file
% INSTRUMENTS: 'horn' 'clarinet' 'oboe' 'bassoon' 'flute' 'piccolo' 'sax', 'trumpet', 'tuba', 'trombone'
in = 'scores/Strauss-Til_Eulenspiegels_Merry_Pranks-opening_horn_solo.csv';
%in = 'scores/Mahler-Symphony_4_last_movement-opening_clarinet_solo_plus_accompaniment.csv';
%in = 'scores/Stravinsky-The_Rite_of_Spring-oboe_solo_near_beginning.csv';
%in = 'scores/Bach_oboe.csv';
%in = 'scores/Stravinsky-The_Rite_of_Spring-opening_bassoon_solo.csv';
%in = 'scores/Debussy-Prelude_a_lApres-midi_dun_Faune-opening_flute_solo.csv';
%in = 'scores/Stravinsky-Rite-of-Spring-piccolo_solo_in_opening.csv';
%in = 'scores/Charlie_Parker_solo-Cool_Blues_1949_transcr.Owens-sax_solo.csv';
%in = 'scores/Bach-Brandenburg_Concerto_2-opening_of_last_movement-trumpet.csv';
%in = 'scores/Berlioz-Symphony_Fantastique,_ending_of_last_movememnt-tuba.csv';
%in = 'scores/Brahms-Symphony_2_ending-trombone.csv';

%in ='scores/Cavallini_ThirtyCaprices_No1.csv'; % clarinet
%in ='scores/Beethoven_Marsch_woO29.csv'; % 2 clarinets, 2 horns, 2 bassoons
%in ='scores/Mozart-Divertimento-II-fragment1.csv'; % oboe, clarinet, bassoon
%in ='scores/Kopprasch-Studies_horn_15.csv'; % horn
%in ='scores/Telemann_Sonata_1.csv'; % piccolo
%in ='scores/Bach_Minuet-xpose.csv'; % trumpet
%in ='scores/Coltrane_Lazybird.csv'; % trumpet sax trombone
%in ='scores/Beethoven_Op18-5-var5_quinteto.csv'; % 2 piccolo flutes, 2 oboes, 2 clarinets, 2 bassoons

%% synthesis
[d notes] = wind_synthesis(fs, in, out, reverb, delay, pr, verbose);