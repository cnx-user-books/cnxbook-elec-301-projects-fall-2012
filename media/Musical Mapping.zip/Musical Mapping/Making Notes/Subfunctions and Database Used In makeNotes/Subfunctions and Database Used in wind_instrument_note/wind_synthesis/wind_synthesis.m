function [d notes] = wind_synthesis(fs, input, output, reverb, delay, pr, verbose)
% synthesis of a piece using wind instrument 
%
% input:
% 	fs    - sampling frequency
% input   - input score file (csv or midi)
% output  - prefix of output files (data and audio)
% reverb  - whether to add reverb or not (0:No-1:Yes)
% delay   - reverb delay time (T60)
% pr      - percentage of reverb added to clean signal
% verbose - 0 - no messages, 
%           1 - warnings and informative messages, 
%           2 - plots       
%
% output:
% 	d     - audio signal
%	notes - amplitude and frequency of each partial of each note

if nargin <  1;          fs =   8000           ; end
if nargin <  2;       input =   'test_horn.csv'; end
if nargin <  3;      output =   'synthesis'    ; end
if nargin <  4;      reverb =   1              ; end
if nargin <  5;       delay =   1.1            ; end
if nargin <  6;          pr =   0.20           ; end
if nargin <  7;     verbose =   1              ; end

%% reverb delays
delays = round([0.0297 0.0371 0.0411 0.0437] * fs);

%% instruments 
instruments = {'horn' 'clarinet' 'oboe' 'bassoon' 'flute' 'piccolo' 'sax', 'trumpet', 'tuba', 'trombone'};

%% event data
disp('Loading score ...')
[events bpm] = load_score(input);

%% synthesis
num_events = size(events,1);
bpm_r = 60/bpm;

% total number of samples (last note + reverb)
last_note_start = round(events(num_events, 2) * bpm_r * fs);
last_note_dur   = round(events(num_events, 3) * bpm_r * fs);
reverb_samples  = round(delay * fs);
total_samples = last_note_start + last_note_dur + reverb_samples;
t = 0:1/fs:total_samples/fs;
t = t(1:end-1);
d = zeros(1,total_samples);

% notes
notes = struct('instrument', {}, 'time_indexes', {}, 'frequency_partials', {}, 'amplitude_partials', {});

disp(['Synthetizing ' num2str(num_events) ' notes ...'])
for i = 1:num_events
    ins = events(i,1);
    dur = events(i,3);
    amp = events(i,4);
    pitch = events(i,5);
    vibr = events(i,6);
    att = events(i,7);
    dec = events(i,8);
    [dd tt f a] = wind_instrument_note(instruments(ins), fs, dur, amp, pitch, vibr, att, dec, bpm);
  
    t_start = events(i,2) * bpm_r;  
    sample_start = round(t_start * fs);
    if (sample_start == 0)
        sample_start = 1;
    end
    sample_end = sample_start+length(dd)-1;
    d(sample_start:sample_end) = d(sample_start:sample_end) + dd;
    
    notes(i).instrument = instruments(ins);
    notes(i).time_indexes = sample_start:1:sample_end;
    notes(i).frequency_partials = f;
    notes(i).amplitude_partials = a;  
end

%% reverb
if reverb
    y = schroeder(d,delays,delay,fs);
    d = (1-pr) * d + pr * y;
end
%% avoid digital zero
d = d + eps;
%% write wav file
disp('Writing audio file ...')
% avoid clipping
clip = max(abs(d));
if  clip > 1
    d = (d / clip) * 0.99;
    for i = 1:num_events
        notes(i).amplitude_partials = (notes(i).amplitude_partials).*(0.99/clip);
    end
end
wavwrite(d,fs,16, [output '.wav']);

%% save data file
disp('Saving data ...')
outputfile = [output '-data'];
%save(outputfile, 'notes');

%% plots

% color for each different instrument
colors = {[0.8,0,0], [0.8,0,0], [0,0,0.8], [0,0.8,0], [0,0.8,0.8], [0.8,0.4,0], [0.8,0,0.8], [0.6,0,0], [0,0,0.6],[0,0.6,0]};

if (verbose > 0)
    % decimation factor
    dec = 10;
    figure; 
    subplot(3,1,1:2)
     
    ind_label = [];
    for i=1:num_events
        ind = find(strcmp(instruments,notes(i).instrument));
        s = find(ind_label == ind);
        if isempty(s)
            ind_label = [ind_label ind];
        end
        plot(t(notes(i).time_indexes(1:dec:end)),notes(i).frequency_partials(:,1:dec:end)','Color',colors{ind});
        hold on
    end
    hold off
    grid
    title('Frequency evolution of each harmonic');xlabel('Time (s)');ylabel('Frequency (Hz)');
    h = gca;
    a = get(h, 'XLim');
    b = get(h, 'YLim');
    xlim(a)
    %axis tight
    for i=1:length(ind_label)
        text(a(end)-0.9, b(end)-i*400, instruments(ind_label(i)), 'Color', colors{ind_label(i)})
    end
    subplot(3,1,3)
    plot(t,d,'k');
    title('Waveform');xlabel('Time (s)');ylabel('Amplitude'); %axis tight
    xlim(a)

    figure
    subplot(3,1,1:2)
    % spectrogram
    t_window = 0.0464;
    window = floor(t_window * fs);
    noverlap = floor(window / 2);
    nfft = window * 2;
    [S,F,T] = spectrogram(d,window,noverlap,nfft,fs);
    bias = linspace(1,length(F),length(F));
    bias = bias/bias(end)*1000;
    BIAS = repmat(bias',1,length(T));
    imagesc(T,F,20*log10(abs(S.*BIAS)+10))
    black = abs(1-gray);
    colormap(black);set(gca,'YDir','normal')

    hold on
    for i=1:num_events
        color = find(strcmp(instruments,notes(i).instrument));
        plot(t(notes(i).time_indexes(1:dec:end)),notes(i).frequency_partials(:,1:dec:end)','Color',colors{color});
        hold on
    end
    hold off
    grid
    title('Frequency evolution of each harmonic');xlabel('Time (s)');ylabel('Frequency (Hz)');
    xlim(a)
    ylim(b)
    for i=1:length(ind_label)
        text(a(end)-0.9, b(end)-i*400, instruments(ind_label(i)), 'Color', colors{ind_label(i)})
    end
    subplot(3,1,3)
    plot(t,d,'k');
    title('Waveform');xlabel('Time (s)');ylabel('Amplitude'); %axis tight
    xlim(a)

    if (verbose > 1)
        figure; 
        subplot(3,1,1:2)
        for i=1:num_events
            color = find(strcmp(instruments,notes(i).instrument));
            plot3(t(notes(i).time_indexes(1:dec:end)),notes(i).frequency_partials(:,1:dec:end)', notes(i).amplitude_partials(:,1:dec:end)','Color',colors{color})        
            hold on
        end
        hold off
        grid
        for i=1:length(ind_label)
            text(a(end)-0.5, b(1), 1-i*0.1, instruments(ind_label(i)), 'Color', colors{ind_label(i)})
        end
        view([150 50])
        title('Frequency and amplitude evolution of each harmonic');xlabel('Time (s)');ylabel('Frequency (Hz)');zlabel('Amplitude');
        subplot(3,1,3)
        plot(t,d,'k');
        title('Waveform');xlabel('Time (s)');ylabel('Amplitude'); %axis tight
        xlim(a)

        figure; 
        subplot(3,1,1:2)
        for i=1:num_events
            color = find(strcmp(instruments,notes(i).instrument));
            plot(t(notes(i).time_indexes(1:dec:end)),notes(i).amplitude_partials(:,1:dec:end)','Color',colors{color})
            hold on
        end
        hold off
        grid
        title('Amplitude evolution of each harmonic');xlabel('Time (s)');ylabel('Amplitude');
        hh = gca;
        bb = get(hh, 'YLim');
        for i=1:length(ind_label)
            text(a(end)-0.9, bb(end)-i*0.05, instruments(ind_label(i)), 'Color', colors{ind_label(i)})
        end
        subplot(3,1,3)
        plot(t,d,'k');
        title('Waveform');xlabel('Time (s)');ylabel('Amplitude'); %axis tight
        xlim(a)
    end  
end

end

