function [events bpm] = load_score(filename)
% [events bpm] = load_score(filename)
% loads a score file to synthetize

events = [];
bpm = 60;

extension = filename(end-2:end);
if strcmp(extension, 'csv')
    % load csv file
    events = csvread(filename);
    % set bpm if present 
    % a 0 instrument number at the begging is used to set bpm
    if (events(1,1) == 0)
        bpm = events(1,2);
        events = events(2:end,:);
    end    
elseif strcmp(extension, 'mid')
    % load midi file
else
    disp('Filename has not .mid or .csv extension')
end


end