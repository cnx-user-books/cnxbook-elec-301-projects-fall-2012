function [d, t, f, a] = wind_instrument_note(instrument, fs, dur, amp, f0, vib, att, dec, bpm, randomphase, verbose)
% wind instrument based on contiguous-group wavetable synthesis, "Cooking with Csound" A. Horner and L. Ayers
%
% input:
% 	fs    - sampling frequency
% 	dur   - duration in seconds
%	amp   - amplitude (0..1)
%	f0    - base frequency
% verbose - 0 - no messages, 
%           1 - warnings and informative messages, 
%           2 - plots       
%
% output:
% 	d   - audio signal
%	t   - vector of sample time instants
%	f   - matrix where each row is the frequency evolution of each partial
%	a   - matrix where each row is the amplitude evolution of each partial
%
%
% examples:
%
% [d, t, f, a] = wind_instrument_note('horn',44100, 1, 1, 400);

if nargin <  1;  instrument = 'horn'; end
if nargin <  2;          fs =   8000; end
if nargin <  3;         dur =      1; end
if nargin <  4;         amp =      1; end
if nargin <  5;          f0 =    100; end
if nargin <  6;         vib =    0.5; end
if nargin <  7;         att =    0.4; end
if nargin <  8;         dec =    0.4; end
if nargin <  9;         bpm =     60; end
if nargin < 10; randomphase =      1; end
if nargin < 11;     verbose =      1; end

%% specific data for the given instrument
amplitudes = instrument_table(instrument, f0);
N_partials = length(amplitudes) + 1;

%% temporal parameters
bpm_r = 60/bpm; % to convert bpm to seconds
dur = dur * bpm_r;
sus = dur - att - dec - 0.005;
MAX_AMP = 2^16/2;

%% first harmonic
[d1, t, f1, a1, p1] = harmonicsource(fs, dur, 1, f0, 'ampscale', 0, 'f0type', 'vibrato', 'vib_depth', vib, 'randomphase', randomphase); %'verbose', verbose);

T = length(t);
f = zeros(N_partials, T);
a = zeros(N_partials, T);
f(1,:) = f1;

%% amplitude envelopes

% piecewise amplitude envelope
transtypes = zeros(1,8);
init = 0.001;
points = [0 0; init 0; init+0.5*att 0.5; init+att 0.9; init+att+0.5*sus 1; ... 
          init+att+sus 0.9; init+att+sus+0.5*dec 0.3; init+att+sus+dec 0; dur 0];

ampt1 = piecewiseampvector(points, transtypes, t, verbose);

% other amplitude envelopes are exponentially related
ampt2 = ampt1 .* ampt1;
ampt3 = ampt2 .* ampt1;
ampt4 = ampt3 .* ampt1;

a(1,:) = a1 .* ampt1;
d1 = d1 .* ampt1;

%% the other harmonics

% different signals for different frequency bands
d2 = zeros(size(d1));
d3 = zeros(size(d1));
d4 = zeros(size(d1));

for i = 2:N_partials;
    if ( amplitudes(i-1) ~= 0)
        % i_th harmonic
        [di ti fi ai] = harmonicsource(fs, dur, 1, i * f0, 'amplitudes', amplitudes(i-1), 'ampscale', 0, 'randomphase', randomphase, 'synthesize_only_harmonics', 1, 'harmonics', i, 'f0t', f1, 'phi', p1);
        % the frequency vector for the partial
        f(i,:) = fi;
        % accumlate signal in the corresponding frequency band    
        % and build the amplitude vector for the partial
        if (i <= 3)
                d2 = d2 + di .* ampt2;
                a(i,:) =  ai .* ampt2;
        else if (i <= 7)
                d3 = d3 + di .* ampt3;
                a(i,:) =  ai .* ampt3;
            else
                d4 = d4 + di .* ampt4;
                a(i,:) =  ai .* ampt4;
            end
        end      
    end
end


%% build signal
if N_partials < 4
    d = d1 + d2;
elseif N_partials < 8    
    d = d1 + d2 + d3;
else
    d = d1 + d2 + d3 + d4;
end

if amp > 0 
    amp_factor = amp / MAX_AMP;
end
norm = amp_factor / max(abs(d));

d = d * norm;
a = a * norm;

% if (amp > 0 && amp <= 1)
%     d = d / sum(amplitudes) * amp;
% else
%     d = d / sum(amplitudes);
%     if verbose
%         disp('Warning: amplitude is not between 0 and 1, forced to 1');
%     end       
% end

%% plots
if (verbose >= 2)
	figure; 
	subplot(3,1,1:2)
	t_window = 0.025;
	window = floor(t_window * fs);
	noverlap = floor(window / 2);
	nfft = window * 2;
	[S,F,T] = spectrogram(d,window,noverlap,nfft,fs);
	imagesc(T,F,10*log10(abs(S)+eps))
	colormap('gray');set(gca,'YDir','normal')
	title('Spectrogram');xlabel('Time (s)');ylabel('Frequency (Hz)');
	subplot(3,1,3)
	plot(t,d,'k');
	title('Waveform');xlabel('Time (s)');ylabel('Amplitude')

	figure; 
	subplot(3,1,1:2)
	plot(t,f','k')
	grid
	ylim([0, fs/2])
	title('Frequency evolution of each harmonic');xlabel('Time (s)');ylabel('Frequency (Hz)');
	subplot(3,1,3)
	plot(t,d,'k');
	title('Waveform');xlabel('Time (s)');ylabel('Amplitude')

	figure; 
	subplot(3,1,1:2)
	plot3(t,f,a,'k')
	grid; ylim([0, fs/2]); view([60 20])
	title('Frequency and amplitude evolution of each harmonic');xlabel('Time (s)');ylabel('Frequency (Hz)');zlabel('Amplitude');
	subplot(3,1,3)
	plot(t,d,'k');
	title('Waveform');xlabel('Time (s)');ylabel('Amplitude')
end

end
