function a = envelopeDetector(s,N)
% 
% 
s = s.^2;
h = ones(1,N)/N;
L = length(s);
l_padding = 2^nextpow2(L)-L;
%a = filter(h,1,s);
a = filter(h,1,[s;zeros(l_padding,1)]);
a = sqrt(a);
end

