%This function takes two input sounds and then mixes them according to the orientation
%of the object. An object that is at 0 degrees (measured from horizontal) will result in a pure 
%tone as will an object with 90/180 degrees of rotation. 
function [Sound] = OrientationSound(Orientations,Upright,Flat)
    time = (1/30)*length(Orientations);
    Out1 = zeros(1,44100*time);
    Out2 = zeros(1,44100*time);
    for i=0:(length(Orientations)-1)
        for x=(i*1470)+1:(i+1)*1470
            Out1(x) = Upright(x)*sin(Orientations(i+1));
            Out2(x) = Flat(x)*cos(Orientations(i+1));
        end
    end
    Sound = (1/abs(max(abs(Out1+Out2))))*(Out1+Out2);
    return