function output = soundSynthesize(theta, v, object, Fs)
%
% This function does musical mapping
%
% Input:
% theta - angle
% v - horizontal velocity
% Fs - sampling rate
% object - name of object
% Output:
% output - synthesized sound
%

% Assign instrument to each object
if strcmp(object, 'bigboard')==1
    instrmt = 'guitar';
elseif strcmp(object, 'smallboard')==1
    instrmt = 'horn';
elseif strcmp(object, 'anteater')==1
    instrmt = 'oboe';
else
    disp('Invalid object');
end

output = [];

% Assign chord and interval for each velocity range
for e = 1:length(v)
    if v(e) > 0 && v(e) < 1000
        notes = {'C2','F#2'};
    elseif v(e) >= 1000 && v(e) < 2000
        notes = {'G2','C#3'};
    elseif v(e) >= 2000 && v(e) < 3000
        notes = {'D3','G#3'};
    elseif v(e) >= 3000 && v(e) < 4000
        notes = {'A3','D#4'};
    elseif v(e) >= 4000 && v(e) < 5000
        notes = {'E4','A#4'};
    else
        disp('Invalid velocity');
    end
    sound = makeNotes(notes, [1 1], instrmt, 'sine', 60, Fs);
    angle = theta(((e-1)*30)+1:30*e);
    temp = OrientationSound(angle, sound(1).notes, sound(2).notes);
    output = [output temp];
end
end