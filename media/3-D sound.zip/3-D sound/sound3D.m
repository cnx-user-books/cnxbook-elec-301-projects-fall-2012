function S = sound3D(s, elev, azim)
%
% This function receives a sound from a specific point in space and
% creates two sounds to the left and right ears in order to produce a 3D
% sound
%
% Input
% s     : the given signal
% elev  : the elevation
% azim  : the azimuth
%
% Output
% S     : a Nx2 matrix whose first column is the sound to the left ear and 
%         whose right column is the sound to the right ear
%

% Set up the reference table for possible locations
pos_table = [];
pos_table(1).azith = 0:5:180;
pos_table(2).azith = 0:5:180;
pos_table(3).azith = 0:5:180;
pos_table(4).azith = 0:6:180;
pos_table(5).azith = [0 6 13 19 26 32 39 45 51 58 64 71 77 84 90 96 103 109 116 122 129 135 141 148 154 161 167 174 180];
pos_table(6).azith = 0:8:176;
pos_table(7).azith = 0:10:180;
pos_table(8).azith = 0:15:180;
pos_table(9).azith = 0:30:180;
pos_table(10).azith = [0];
pos_table(11).azith = 0:5:180;
pos_table(12).azith = 0:5:180;
pos_table(13).azith = 0:6:180;
pos_table(14).azith = [0 6 13 19 26 32 39 45 51 58 64 71 77 84 90 96 103 109 116 122 129 135 141 148 154 161 167 174 180];

% round elev and azim
if (elev > 90)
    elev =90;
elseif (elev < -40)
    elev = -40;
else
    elev = round(elev/10)*10;
end

if elev >= 0
    [m, index] = min(abs(pos_table(elev/10+1).azith-abs(azim)));
    azim2 = pos_table(elev/10+1).azith(index);
else
    [m, index] = min(abs(pos_table(-elev/10+10).azith-abs(azim)));
    azim2 = pos_table(-elev/10+10).azith(index);
end


l = length(s); % length of the given signal
[x] = readhrtf(elev,azim2,'H'); % read in the impose response at
% given azimuth and elevation


% Synthesize sounds introduced to the left and right ear
if azim >=0
    sr = conv(s, x(2,:));
    sl = conv(s, x(1,:));
else
    sr = conv(s, x(1,:));
    sl = conv(s, x(2,:));
end

S = [sl,sr];

end



