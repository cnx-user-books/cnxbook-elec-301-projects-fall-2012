function output = doppler(input, v)
%
% This function mimics the Doppler effect to encode the angular velocity of
% the object into our final sound. If the angular velocity is counter-clock 
% wise, it is positive. If the angular velocity is clock-wise, it is
% negative. If the angular velocity is v, then we will multiply the
% frequencies of the sound by (c+v)/(c-v0) where c is 343 and v0 = 0.
%
% Input
% input - the original sound
% v     - angular velocity
%
% Output
% output - the resultant sound
%


% generating vector of frequency changes due to doppler effect
input=input';
N = length(input); % number of samples

c = 343; % sound velocity
v0 = 0; % the velocity of the observer is = 0 metres per second

% vector of frequency change coefficients
f_coeff = (c + v)/(c - v0)*ones(1,N);

% Applying doppler effect to resample wave file 

chunksize = 500; % length of one chunk
overlap = 0; % percentage overlap
numChunks = ceil(N/(chunksize*(1-(overlap/100)))); % number of chunks
output = 0; % initialise output
for i = 0:numChunks-1
     istart = (i * chunksize + 1)-(chunksize*i*(overlap/100)); 
     iend = istart + chunksize;
     if iend > N; 
         iend = N;
     end
     fcoeff_av = floor(mean(f_coeff(istart:iend))*100)/100;
     output = [output resample(input(istart:iend), 100, floor(fcoeff_av*100))];
end

% Filter out the noise
output=output./max(abs(output));% Normalise
output = output';
eY = fft(output); % Fourier transform of noisy signal 
n = size(output,2)/2; % use size for scaling
amp_spec = abs(eY)/n;
fY = fix(eY/50)*50; % set numbers < 100 to zero
ifY = ifft(fY); % inverse Fourier transform of fixed data
output = real(ifY);

end


