function output = Top_function(temp, object) 
% 
% This function works as the top function that combines all functions we
% wrote in our ELEC 301 final project to detect objects and their motion,
% do musical mapping and create 3-D sounds.
%
% Input
% temp: reference name-'ref1.png','ref2.png','ref3.png'
% object: 'bigboard','smallboard','anteater' 
%
% Output
% output : the resultant Nx2 sound matrix 
%
Fs = 44100; 
% Read the video file and output objects' position, velocity, and orientation
treshold = 0.0005;
match = 6;

vid = 'IMG_0102.MOV';
[~,~,~,~,~,ang,xvave,yvave,xave,yave,~]=tracking2(match,treshold,temp,vid);
temp_x2 = xave;
temp_y2 = yave;
v =sqrt(xvave.^2+yvave.^2);

ang = envelopeDetector(ang',100);
% Create sound and encode the orientation into it
theta = ang;
output = soundSynthesize(ang, v, object, Fs);
if strcmp(object, 'bigboard')==1
    instrmt = 'guitar';
elseif strcmp(object, 'smallboard')==1
    instrmt = 'horn';
elseif strcmp(object, 'anteater')==1
    instrmt = 'oboe';
else
    disp('Invalid object');
end

output = [];

minv = min(v);
maxv = max(v);
delv = maxv - minv;

for e = 1:length(v)
    if v(e) >=  minv && v(e) < (minv+delv/5)
        notes = {'C2','F#2'};
    elseif v(e) >= (minv+delv/5) && v(e) < (minv+delv*2/5)
        notes = {'G2','C#3'};
    elseif v(e) >= (minv+delv*2/5) && v(e) < (minv+delv*3/5)
        notes = {'D3','G#3'};
    elseif v(e) >= (minv+delv*3/5) && v(e) < (minv+delv*4/5)
        notes = {'A3','D#4'};
    elseif v(e) >= (minv+delv*4/5) && v(e) <= maxv
        notes = {'E4','A#4'};
    else
        disp('Invalid velocity');
    end
    sound = makeNotes(notes, [1 1], instrmt, 'sine', 60, Fs);
    angle = theta(((e-1)*30)+1:30*e);
    temp = OrientationSound(angle, sound(1).notes, sound(2).notes);
    temp = temp';
    S_temp = sound3D(temp,90-yave(e),90-xave(e));
    output = [output;S_temp];
end



